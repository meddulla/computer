# @cloudflare/kitebuild-git

A JavaScript `git` for Kitebuild machines. It runs isomorphic-git over the
machine's VFS and registers as a program, so shell scripts can call `git`.

```ts
import { ProgramRegistry } from "@cloudflare/kitebuild-core/programs";
import BUSYBOX from "@cloudflare/kitebuild-core/artifacts/busybox.wasm";
import { git } from "@cloudflare/kitebuild-git";

const programs = new ProgramRegistry({
  defaultProgram: { module: BUSYBOX, abi: "linux" },
  programs: git().programs,
});
```

`git()` returns a toolset, `{ programs, extras? }`, which embedders such as
`@cloudflare/computer`'s `KitebuildBackend` take directly. Pass
`git({ fetch })` to send clone, fetch and push requests through a fetch that
applies your egress policy; `git` calls `fetch` itself, so the machine's egress
policy does not cover it otherwise. `git push [-u] [-f] [<remote>
[<src>[:<dst>]]]` works from a repository, as in git: it needs a credential the
guest exports (`GITHUB_TOKEN`, `GITLAB_TOKEN`, or `GIT_USERNAME`/`GIT_PASSWORD`)
or that your `fetch` adds, and your `fetch` decides which remotes it reaches.
`git({ push: false })` refuses it. The toolset's `extras` belong in
`MachineOpts.extras`. `gitMain` remains exported for registering the program by
hand.

The applet runs a bundled copy of isomorphic-git 1.38.3 with this repository's
memory patch (`patches/npm`), built by `scripts/prebundle.mjs` into
`src/generated/` and shipped in the published package, so large clones and
checkouts stay within a Worker's memory without the consumer patching anything.
The `isomorphic-git` dependency remains for its HTTP client and types.

`createGitHttp` and `makeVfsFs` expose the HTTP transport and the VFS-backed
filesystem shim for callers that drive isomorphic-git directly.

## Commands

`init`, `clone`, `status`, `log`, `diff`, `grep`, `add`, `commit`, `merge`, `branch`, `checkout`,
`switch`, `restore`, `remote`, `config`, `rev-parse`, `show`, `fetch`,
`submodule update`, `pull`, `push`, `apply`, `ls-files`, `rm`, `mv`, `reset`,
`cherry-pick`, `revert`, `rebase`, `stash`, `tag`, `blame`, `merge-base`,
`rev-list`, `ls-tree`, `cat-file`, `check-ignore`, and `ls-remote`. Options outside the supported subset fail by name rather than being
ignored.

- `reset` supports `--soft`, `--mixed` (the default), and `git reset [<rev>]
  -- <paths>`. `--hard`, `--merge`, and `--keep` are refused.
- `cherry-pick [-x] <commit>...` and `revert [--no-edit] <commit>...` apply
  each commit with the same tree merge as `merge`. A conflict stops in git's
  state (`CHERRY_PICK_HEAD` or `REVERT_HEAD`, `MERGE_MSG`, index stages, and
  `.git/sequencer` for the rest of a sequence), resumed with `--continue` (or
  `commit`) and `--skip`, or undone with `--abort`; `--quit` leaves the result.
  As in git they refuse a dirty index and local changes to files they touch.
- `rebase [--onto <newbase>] [<upstream> [<branch>]]` replays the branch's
  commits on the new base, rebasing onto the configured upstream when none is
  given. As in git it refuses uncommitted changes and untracked files it would
  overwrite, drops merge commits, leaves out commits whose patch is already
  upstream (comparing patch fingerprints, as git's patch-id does), and drops a
  commit that becomes empty. A conflict stops in git's state
  (`.git/rebase-merge`, `REBASE_HEAD`), reported by `status`, and is resumed
  with `--continue` or `--skip`, or undone with `--abort`; `--quit` leaves HEAD
  where it is. `-i` is refused.
- `merge [--ff | --no-ff | --ff-only] [-m <msg>] [--no-commit] [-q] [-n]
  [--allow-unrelated-histories] <commit>` fast-forwards, or makes a merge
  commit with git's message. It merges trees and files itself (file contents
  with the diff3 algorithm, so an ambiguous change can conflict differently
  from git's), and on a conflict leaves git's state: conflict markers, index
  stages 1-3, `MERGE_HEAD` and `MERGE_MSG`. Resolve with `add`/`rm` or
  `checkout --ours`/`--theirs`, then `commit` (which uses `MERGE_MSG`) or
  `merge --continue`; `merge --abort` puts everything back. As in git it
  refuses staged changes, local changes to merged files, and untracked files
  it would overwrite. During a conflict `status` reports unmerged paths,
  `ls-files` lists their stages, and `diff` names them (`* Unmerged path`)
  rather than printing git's combined diff. Octopus merges, `--squash` and
  strategies are refused.
- `grep [-n] [-i] [-w] [-v] [-l | -L | -c | -o | -q] [-E | -F] [-e <pattern>]...
  [-A | -B | -C <n>] [-I] [-h] [--cached | <tree>...] <pattern> [--] [<paths>]`
  searches tracked files in the working tree, the index, or commits, in git's
  POSIX basic syntax by default (translated to JavaScript regular expressions),
  limited to the current directory unless given paths.
- `worktree add [-b | -B <new>] [--detach] [-f] <path> [<commit-ish>]`,
  `list [--porcelain]`, `remove [-f]`, `move` and `prune [-n] [-v]` keep git's
  layout (a `.git` file pointing at `.git/worktrees/<name>`), so either git can
  use the other's worktrees. Inside a linked worktree every command works on
  its own HEAD, index and merge or rebase state and the shared objects and
  refs; a branch checked out in one worktree cannot be checked out or deleted
  in another, and `branch` marks such branches with `+`. `lock`, `unlock` and
  `repair` are refused.
- `blame [-L <start>,<end>] [-s] [<rev>] [--] <file>` blames the working tree
  when no revision is given. It does not follow renames, and its line diff is
  not git's, so an ambiguous alignment can be credited differently.
- Revisions accept refs, abbreviated ids, `@`, and `~N`/`^N` suffixes in
  `rev-parse`, `reset`, `cherry-pick`, `revert`, `rebase`, and `blame`.
- `log` and `show` take `--pretty=`/`--format=` as `format:`, `tformat:`, a
  bare string with placeholders, `oneline`, or `medium`, and `--date=` as
  `default`, `short`, `iso`, `iso-strict`, `rfc`, `raw`, or `unix`.
  Placeholders: `%H %h %T %t %P %p %s %b %B %n %%`, and for author (`a`) or
  committer (`c`) `n e d t i I s` (`%an`, `%cd`, ...).
- `log` walks history as git does: newest commit date first, from any number
  of revisions, `A..B`, `A...B`, `^A` and `--all`, limited to `-- <paths>`
  (or paths that name no revision) with git's default history simplification.
  It filters with `-n`, `--grep`, `-i`, `--author`, `--since`/`--until`
  (ISO dates, `@<seconds>`, `<n> <unit>s ago`), `--merges`, `--no-merges`,
  `--first-parent`, `-S<string>`, and `--reverse`. `-p`, `--stat` (and the
  two together), `--numstat`, `--shortstat`, `--name-only` and `--name-status`
  show each commit's changes, in git's layout for each format. `--graph` is
  refused.
- `diff` compares the index with the working tree, a commit with the index
  (`--cached`/`--staged`) or the working tree, two commits, `A..B`, or `A...B`
  (from the merge base), limited to paths. It prints git's patch (with
  function context, `-U<n>`, `--no-prefix`), `--stat` (an 80-column layout),
  `--numstat`, `--shortstat`, `--name-only` or `--name-status`, filters with
  `--diff-filter`, and exits 1 with `--quiet`/`--exit-code` when anything
  differs. Binary files are reported as such. Renames are detected when the
  content is identical; a renamed and edited file shows as a deletion and an
  addition. The line alignment is not git's xdiff, so an ambiguous change can
  be split into hunks differently.
- `show <commit>` prints the patch after the message, or any of the diff
  options above; for a merge, stats are against the first parent and the
  patch is git's combined diff only when that is empty (a clean merge).
- `show <rev>:<path>` prints a file's bytes or a directory's listing, and
  `:<path>` reads the index; `rev-parse` resolves the same forms.
- `status` supports the long format, `--short`/`-s`, `--porcelain`, `--branch`
  (`## branch...upstream [ahead N, behind M]`), `-u`/`--untracked-files=` and
  `--ignored`.
- `commit` takes bundled short options (`-qam <msg>`), several `-m`, `-F`,
  `--amend` (with `--no-edit`), `--fixup`, `--allow-empty` and `--author`,
  cleans the message as git does, and refuses, printing the status, when
  nothing is staged. There is no editor: give the message on the command line.
  Its summary, like `cherry-pick`'s and `revert`'s, ends with git's short stat
  and `create mode`/`delete mode` lines.
- `add [-A | -u] [-f] [<pathspec>...]` stages everything under a pathspec,
  deletions included; ignored files need `-f`.
- `ls-files` supports `--cached`, `--others`, `--modified`, `--deleted`,
  `--stage`, `--ignored` with `--exclude-standard`, and `-z`, relative to the
  current directory.
- `rev-parse` supports `--short[=N]`, `--verify` with `-q`, `--abbrev-ref`,
  `--symbolic-full-name`, `--git-dir`, `--git-common-dir`, `--git-path`,
  `--show-toplevel`, `--show-prefix` and `--show-cdup`.
- `branch` lists with `-a`, `-r`, `--list [<pattern>]`, `-v`/`-vv`,
  `--contains`, `--points-at` and `--format`, renames with `-m`/`-M`, deletes
  with `-d` (refusing an unmerged branch) or `-D`, and sets or unsets the
  upstream with `-u`/`--set-upstream-to` and `--unset-upstream`.
  `--show-current` prints the current branch, or nothing when HEAD is detached.
- `clone` supports `--depth`, `--branch`, `--single-branch`, `--no-checkout`
  and `-q`; `--filter` is accepted but every object is fetched. `fetch`, `pull`
  and `push` accept `-q`; `push` also takes `--force-with-lease[=<ref>[:<expect>]]`.
- `switch [-c | -C <new>] [--detach] [<branch>]` and `restore [--source <rev>]
  [--staged] [--worktree] <paths>` follow git. `switch -` and `@{-1}` need the
  reflog, which isomorphic-git does not keep, and are refused.
- `stash [push [-u] [-m <msg>] [<paths>]] | pop | apply [--index] | list |
  drop | clear` writes git's stash format (an index commit, a working-tree
  commit, and with `-u` an untracked-files commit, named by `refs/stash` and its
  reflog), so either git reads the other's stashes. Applying refuses, changing
  nothing, over local changes to a stashed file, as git does, and when a stashed
  file changed in HEAD since, which would need a content merge. `stash show`
  takes `--stat` (the default), `-p`, `--name-only`, `--name-status` and
  `--numstat`.
- `tag` lists (`-l [<pattern>]`, `-n`, `--contains`, `--points-at`), creates
  lightweight or annotated (`-a`/`-m`) tags, and deletes with `-d`.
- `mv`, `merge-base [--all | --is-ancestor]`, `rev-list` (the `log` walk, with
  `--count`), `ls-tree [-r] [-d] [-t] [-l] [--name-only]`, `cat-file (-e | -t |
  -s | -p | <type>)`, `check-ignore [-v] [-n] [-q]` and `ls-remote [--heads]
  [--tags] [--refs]`.
- `status` reports a staged rename when a file is removed and an identical
  one added, which is what `mv` leaves; renames with edits are not detected.
- Output is coloured, and `log` decorates HEAD, only when stdout is a terminal,
  as git's defaults.
- `checkout <branch>` switches (creating a local branch from `<remote>/<branch>`
  when only that exists), `checkout <commit>` and `checkout --detach [<rev>]`
  detach HEAD, and `checkout [<rev>] [--] <paths>` restores those paths from
  the index, or from `<rev>` into the index and working tree, leaving files the
  source lacks alone. `-q` silences the report.
- `rm [-r] [-f] [-q] [--cached] <paths>` refuses, as git does, to drop changes
  that exist nowhere else unless given `-f`; `--cached` keeps the file.
- `init [-q] [-b <branch>] [<directory>]`.
- `branch <name> [<start>]` and `checkout -b <name> [<start>]` create the branch
  at the start point (default HEAD). A remote-tracking start such as
  `origin/main` becomes the branch's upstream, as in git. `checkout -b` keeps
  unrelated local edits and refuses, without creating the branch, when the
  switch would overwrite one.
- `config` gets and sets keys, and supports `--list`/`-l`, `--get-regexp
  <key-regex> [<value-regex>]`, and `--show-origin`. Only the repository's own
  config exists; `--global` and `--local` both address it. It parses config
  with isomorphic-git, which reads a key written without `=` as `true` and
  keeps a comment that follows a quoted value.

`status` and `commit -a` see every rewrite, including one with the same size
in the same second: the filesystem shim reports each file body's generation
counter as its change time, so a stale index entry is never trusted.
