# @cloudflare/kitebuild-git-applet

A JavaScript `git` for Kitebuild machines. It runs isomorphic-git over the
machine's VFS and registers as a program, so shell scripts can call `git`.

```ts
import { ProgramRegistry } from "@cloudflare/kitebuild-core/programs";
import BUSYBOX from "@cloudflare/kitebuild-core/artifacts/busybox.wasm";
import { git } from "@cloudflare/kitebuild-git-applet";

const programs = new ProgramRegistry({
  defaultProgram: { module: BUSYBOX, abi: "linux" },
  programs: git().programs,
});
```

`git()` returns a toolset, `{ programs, extras? }`, which embedders such as
`@cloudflare/computer`'s `KitebuildBackend` take directly. Pass
`git({ fetch })` to send clone, fetch and push requests through a fetch that
applies your egress policy; `git` calls `fetch` itself, so the machine's egress
policy does not cover it otherwise. `git push` is refused unless the host grants it:
`git({ push: true })` allows pushes from a repository (`git push [-u] [-f]
[<remote> [<src>[:<dst>]]]`), usually together with a `fetch` that adds the
host's credentials. The toolset's `extras` belong in
`MachineOpts.extras`. `gitMain` remains exported for registering the program by
hand.

The applet runs a bundled copy of isomorphic-git 1.38.3 with this repository's
memory patch (`patches/npm`), built by `scripts/prebundle.mjs` into
`src/generated/` and shipped in the published package, so large clones and
checkouts stay within a Worker's memory without the consumer patching anything.
The `isomorphic-git` dependency remains for its HTTP client and types.

`createGitHttp` and `makeVfsFs` expose the HTTP transport and the VFS-backed
filesystem shim for callers that drive isomorphic-git directly.

## Commands

`init`, `clone`, `status`, `log`, `add`, `commit`, `branch`, `checkout`,
`remote`, `config`, `rev-parse`, `show`, `fetch`, `submodule update`, `pull`,
`push`, `apply`, `ls-files`, `rm`, `reset`, `cherry-pick`, `revert`, and
`blame`. Options outside the supported subset fail by name rather than being
ignored.

- `reset` supports `--soft`, `--mixed` (the default), and `git reset [<rev>]
  -- <paths>`. `--hard`, `--merge`, and `--keep` are refused.
- `cherry-pick [-x] <commit>...` and `revert [--no-edit] <commit>...` refuse a
  dirty index or uncommitted work in a path the commit touches, as git does. A
  conflict changes nothing and exits 1; there is no `--continue` or `--abort`.
- `blame [-L <start>,<end>] [-s] [<rev>] [--] <file>` blames the working tree
  when no revision is given. It does not follow renames, and its line diff is
  not git's, so an ambiguous alignment can be credited differently.
- Revisions accept refs, abbreviated ids, `@`, and `~N`/`^N` suffixes in
  `reset`, `cherry-pick`, `revert`, and `blame`.
- `log` and `show` take `--pretty=`/`--format=` as `format:`, `tformat:`, a
  bare string with placeholders, `oneline`, or `medium`, and `--date=` as
  `default`, `short`, `iso`, `iso-strict`, `rfc`, `raw`, or `unix`.
  Placeholders: `%H %h %T %t %P %p %s %b %B %n %%`, and for author (`a`) or
  committer (`c`) `n e d t i I s` (`%an`, `%cd`, ...). `log` also takes
  `-n`, `-<n>`, `--max-count`, `--oneline`, and one starting revision.
- `branch --show-current` prints the current branch, or nothing when HEAD is
  detached.
- `config` gets and sets keys, and supports `--list`/`-l`, `--get-regexp
  <key-regex> [<value-regex>]`, and `--show-origin`. Only the repository's own
  config exists; `--global` and `--local` both address it. It parses config
  with isomorphic-git, which reads a key written without `=` as `true` and
  keeps a comment that follows a quoted value.

`status` and `commit -a` see every rewrite, including one with the same size
in the same second: the filesystem shim reports each file body's generation
counter as its change time, so a stale index entry is never trusted.
