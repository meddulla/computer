# @cloudflare/kitebuild-core

The Linux and WASI runtime underlying Kitebuild. It provides `Machine`, the
virtual filesystem, process and descriptor handling, syscall emulation, mounts,
and a program registry without importing Kitebuild's optional applets.

```ts
import { Machine } from "@cloudflare/kitebuild-core/machine";
import { ProgramRegistry } from "@cloudflare/kitebuild-core/programs";
import BUSYBOX from "@cloudflare/kitebuild-core/artifacts/busybox.wasm";
import INITRAMFS from "@cloudflare/kitebuild-core/artifacts/initramfs.wasm";

const programs = new ProgramRegistry({
  defaultProgram: { module: BUSYBOX, abi: "linux" },
});

const output: Uint8Array[] = [];
const machine = new Machine({
  programs,
  initramfs: INITRAMFS,
  mounts: [
    {
      type: "sqlite",
      vfsPath: "/workspace",
      storage: ctx.storage,
    },
  ],
  wsSend(data) {
    output.push(typeof data === "string" ? new TextEncoder().encode(data) : data);
  },
  log() {},
});

await machine.run(["busybox", "sh", "-c", "echo hello"]);
```

Use the narrow `/machine`, `/vfs`, `/sqlite`, and `/programs` exports when a
consumer does not need the complete API barrel. The wasm imports require a
Workers-compatible compiled-wasm module rule.

## Filesystem seams

The VFS keeps paths, directory topology and open-file state in memory and
delegates persistence to a mount backend. Each layer below is a separate
contract, so a store, sync or checkpoint consumer can adopt one without the
others.

- **Mount backend** (`VfsPersistence` from `/vfs`). The VFS calls `create`,
  `remove`, `rename` and the optional `link`, `update`, `flush` and
  `prefetchFiles` hooks before it changes its in-memory tree. Each returns 0, a
  node, or a negative errno; an error leaves the tree unchanged. A directory
  whose entries live in the backend can use `LazyChildren` to load them on first
  access.
- **Chunk store** (`ChunkStore`, `ChunkBodies` from `/vfs`). A store maps a body
  ID and chunk index to bytes, plus each body's size and modification time. It
  chooses its own `chunkSize`, reads absent chunks as zeros, and persists each
  `commit` batch atomically. `ChunkBodies` turns a store into file bodies with a
  bounded cache and optional write-back buffering.
- **Change events** (`Vfs.observeChanges`, `Vfs.trackMutations`). Every create,
  link, remove, rename, metadata update and body write made through a `Vfs` is
  reported with its parent node and name as well as its path, so a consumer can
  follow inode identity. Changes made directly to storage are not reported.
- **Manifests** (`/manifest`). Versioned file manifests (one file's ordered
  chunk hashes and sizes, as `{"version":1,"chunks":[{"hash","size"}]}` JSON), directory
  manifests (one directory's entries with their metadata and file or
  subdirectory manifest hash), and tree manifests (the same tree flattened to
  every path). A tree's hash is its root's, computed through the directory
  layer, so an unchanged subtree keeps its hash. All have versioned canonical
  encodings and SHA-256 hashes. `diffTreeManifests` lists the paths two trees
  add, remove, or change, and the file contents the newer one needs. `vfsTree`
  (from `/vfs`) describes a directory of any loaded mount as a tree manifest,
  hashing files in `FILE_MANIFEST_CHUNK_BYTES` chunks so the result matches a
  SQLite snapshot of the same tree.
- **Conformance** (`/conformance`). `conformanceCases` run against any backend
  that provides `mount()` and declares whether it is durable, supports hard
  links, and offers invalidation or snapshots. `shellConformanceCases` drive a
  backend that only works through the kernel, such as R2, host, and artifacts
  mounts, with BusyBox scripts in fresh Machines. A missing capability is
  checked through the error the backend reports (`EPERM` for links and
  symlinks, `EOPNOTSUPP` for directory renames, `EROFS` for any change to a
  read-only mount) rather than skipped. The cases throw on failure and import
  no test framework. Core runs the VFS cases against memory, both SQLite modes,
  and a fake chunk store, and the shell cases against memory, writable and
  read-only R2, a read-only host mount, and an artifacts mount.

The SQLite backend (`/sqlite`) implements all of these over Durable Object
storage. `mountSqliteFs` returns a mount with `flush()`, `snapshot()`, which
publishes a snapshot that pins its chunks and records only what changed since
the mount's previous snapshot. `restoreSqliteFsSnapshot` recreates a snapshot
in an empty namespace without copying chunk bytes, and `pruneSqliteFsSnapshots`
deletes the snapshots no longer needed. See [`docs/sqlite-vfs.md`](../../docs/sqlite-vfs.md) for
the schema, garbage collection and migration.
